from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.raw', 'twisted.pair.raw',
                         'Interfaces for raw packets', 'Pair',
                         'http://twistedmatrix.com/projects/pair',
                         globals())

